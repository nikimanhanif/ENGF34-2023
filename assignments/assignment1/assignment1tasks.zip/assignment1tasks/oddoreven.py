no = int (input("Enter any number: "))

if (no % 2) == 0:
    print (f"{no} is even")

else:
    print (f"{no} is odd")
    