def gcd(a, b):
    while not a == b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a
ax = 23468
bx = 50446
print("GCD of", ax, "and", bx, "is", gcd(ax, bx))